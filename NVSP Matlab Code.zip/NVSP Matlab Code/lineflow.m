SLT = 0;
fprintf('\n')
fprintf('                           Line Flow and Losses \n\n')
fprintf('   --Line--    Power at bus & line flow    --Line loss--  Transformer\n')
fprintf('   from    to    MW      Mvar     MVA       MW      Mvar      tap\n')
   for L = 1:nbr;
        n=nl(L);
        k=nr(L);
       In = (V(n) - a(L)*V(k))*y(L)/a(L)^2;
        Ik = (V(k) - V(n)/a(L))*y(L) ;
       Snk = V(n)*conj(In)*basemva;
       Skn = V(k)*conj(Ik)*basemva;
        SL  = Snk + Skn;
        SLT = SLT + SL;
        SLTN(L)=Snk;
         fprintf('%5g  %5g',n, k),
         fprintf('%9.2f', real(Snk)), fprintf('%9.2f', imag(Snk))
         fprintf('%9.2f', abs(Snk)),
         fprintf('\n');
         fprintf('%5g  %5g',k, n),
         fprintf('%9.2f', real(Skn)), fprintf('%9.2f', imag(Skn))
         fprintf('%9.2f', abs(Skn)),
         fprintf('%9.2f', real(SL)),
         if a(L) ~= 1
             fprintf('%9.2f', imag(SL)), fprintf('%9.4f\n', a(L))
         else
             fprintf('%9.2f\n', imag(SL))
         end
   end
   %  SLT = SLT/2;
fprintf('   \n'), fprintf('    Total loss                         ')
fprintf('%9.2f', real(SLT)), fprintf('%9.2f\n', imag(SLT))
%   clear Ik In SL SLT Skn Snk
Bc;