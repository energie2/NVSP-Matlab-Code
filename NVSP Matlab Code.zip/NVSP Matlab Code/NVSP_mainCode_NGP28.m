

clear;
clc;
basemva = 100;  accuracy = 0.0001;  maxiter = 100;

%        28-BUS Nigerian Power Network (NGP)
%        Bus Bus  Voltage Angle   ---Load---- -------Generator----- Static Mvar
%        No  code Mag.    Degree  MW    Mvar  MW  Mvar Qmin Qmax    +Qc/-Ql
busdata=[1   1    1.05    0.0   68.9   51.7  251.538 641.299 0.0   0   0  
         2   2    1.05   15.424  0.0    0.0  670.0    82.628  0     0    0
         3   0    1.04   -0.570 274.4 205.8    0.0  0.0   0   0       0
         4   0    0.97    0.482 344.7 258.5    0.0  0.0   0   0       0
         5   0    0.986   1.408 633.2 474.9    0.0  0.0   0   0       0
         6   0    1.026   8.739  13.8  10.3    0.0  0.0   0   0       0
         7   0    1.046  14.04   96.5  72.4    0.0  0.0   0   0       0
         8   0    1.011   9.306 383.4 287.5    0.0  0.0   0   0       0
         9   0    0.932   2.335 275.8 206.8    0.0  0.0   0   0       0
        10   0    0.966   8.642 201.2 150.9    0.0  0.0  0.0  0       0    
        11   2    1.05   13.273  52.5  39.4  431.0 590.551   0.0  0.0   0 
        12   0    1.007  12.057 427.0 320.2  0.0    0    0     0   0       
        13   0    0.905   3.322 177.9 133.4    0    0    0  0       0
        14   0    0.949   6.268 184.6 138.4    0    0     0   0       0
        15   0    1.01   26.299 114.5  85.9    0.0   0.0    0    0     0
        16   0    0.844  4.905  130.6  97.9    0    0     0   0       0
        17   0    1.046  25.523  11     8.2   0.0    0    0     0   0  
        18   2    1.05   26.022  0.0    0.0 495    159.23     0   0       0
        19   0    0.93   12.901  70.3   52.7   0    0    0     0   0     
        20   0    0.951   8.791  193   144.7   0    0     0   0       0
        21   2    1.05   31.819  7.5    5.2 624.7  -65.319 0   0       0
        22   0    0.818 -1.562   220.6  142.9    0    0     0   0       0
        23   2    1.05   13.479   70.3   36.1    388.9   508.034     0   0       0
        24   2    1.05   12.015  20.6   15.4   190.3   283.405     0   0     0
        25   0    0.951  21.703  110    89    0    0     0   0       0
        26   0    1       9.242  290.1 145       0    0     0   0       0
        27   2    1.05   46.869  0     0.0    750   193.093     0   0       0
        28   2    1.05   5.871   0     0.0    750   488.128     0   0       0];

%                                        Line code
%         Bus bus   R      X     1/2 B   = 1 for lines
%         nl  nr  p.u.   p.u.   p.u.     > 1 or < 1 tr. tap at bus nl
linedata=[3   1   0.00066   0.00446   0.06627    1
          4   5   0.0007   0.00518   0.06494    1
          1   5   0.00254  0.01728   0.25680    1
          5   8   0.01100  0.08280   0.40572    1
          5   9   0.00540  0.04050   0.00000    1
          5   10  0.01033  0.07682   0.96261    1
          6   8   0.00799  0.05434   0.80769    1
          2   8   0.00438  0.03261   0.40572    1
          2   7   0.00123  0.00914   0.1146    1
          7   24  0.00258  0.01920   0.24065    1
          8   14  0.00561  0.04176   0.52332    1
          8  10   0.01029  0.07651   0.95879      1
          8  24   0.00205  0.01393   0.2071          1
          9  10   0.00471  0.03506   0.43928          1
         15  21   0.01271  0.09450   1.18416      1
         10  17   0.00643  0.04786   0.59972          1
         11  12   0.00102  0.00697   0.10355          1
         12  14   0.00566  0.04207   0.52714          1
         13  14   0.00393  0.02926   0.36671          1
         16  19   0.01082  0.08048   1.00844          1
         17  18   0.00033  0.00223   0.03314          1
         17  23   0.0100   0.07438   0.93205          1
         17  21   0.00332  0.02469   0.30941          1
         19  20   0.00803  0.05975   0.74869          1
         20  22   0.00943  0.07011   0.87857          1
         20  23    .00393    .02926  0.36671          1
         23  26    .00614    .04180  0.6213          1
         12  25    .0071    .0532   0.38          1
         14  27    .00213    .01449  0.21538          1
         25  27    .0079    .0591   0.39000          1
         5   28    .00160    .01180  0.09320          1];

lfybus;    % Flow bus admittance matrix
lfnewton;  % Power flow solution by Newton Raphson method
busout;    % Prints the power flow solution on the screen
lineflow;  % Computes and displays the line flow and losses
lfybus;    % Flow bus admittance matrix
lfnewton;  % Power flow solution by Newton Raphson method
busout;    % Prints the power flow solution on the screen
lineflow;  % Computes and displays the line flow and losses
lfybus;    % Flow bus admittance matrix
lfnewton;  % Power flow solution by Newton Raphson method
busout;    % Prints the power flow solution on the screen
lineflow;  % Computes and displays the line flow and losses
R=linedata(:,3);
X=linedata(:,4);
p=linedata(:,1);
q=linedata(:,2);
Z=R+j*X;
Z=abs(Z);
N=length(linedata(:,1));
Qd=Qd/basemva;
Pd=Pd/basemva;
Vm=Vm';
Sd=Pd+j*Qd;
Sd=abs(Sd);
fb=linedata(:,1);
tb=linedata(:,2);

S=S*basemva;
MVA=abs(SLTN)';
MVAA=diag(abs(S));

% Computation for the Voltage Stability Pointer (NVSP)

for ki=1:N
    p=fb(ki);q=tb(ki);
    X(p,q)=X(ki);
    Z(p,q)=Z(ki);
    NVSP(ki)=(4 *(Qd(q)*Z(p,q)))/(Vm(p)^2); % Computes the New Voltage Stability Pointer
end



fprintf('\n');
disp('       NVSP Results');
disp('---------------------------------------');
disp('|From|To |  NVSP  |');
disp('|Bus |Bus|  p.u   |');
for m = 1:N
    p = fb(m); q = tb(m);
    disp('------------------------------------------------');
    fprintf('%4g', p); fprintf('%4g', q); fprintf('  %8.4f', NVSP(m));
end
fprintf('\n');
disp(' |Active Power Loss| Reactive Power Loss|  Total NVSP| ' );
disp(' |       (MW)      |       (MVAR)       |    (p.u)  | ' );
disp('--------------------------------------------------------------------------------------------------------------------');
fprintf('%13.4f', real(SLT)); fprintf('%20.4f', imag(SLT)); 
fprintf('  %9.4f', sum(NVSP)); fprintf('\n');

figure; plot (Vm,'-','linewidth',1.5);
ylabel('Voltage Magnitude (p.u.)');
xlabel('Bus Number'); grid on;
xticks([1:N]);
