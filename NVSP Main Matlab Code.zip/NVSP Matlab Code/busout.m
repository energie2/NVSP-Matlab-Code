%  This program prints the power flow solution in a tabulated form
%  on the screen.

%clc
disp(tech)
fprintf('                      Maximum Power Mismatch = %g \n', maxerror)
fprintf('                             No. of Iterations = %g \n\n', iter)
head =['    Bus  Voltage  Angle    ------Load------    ---Generation---   Injected'
       '    No.  Mag.     Degree     MW       Mvar       MW       Mvar       Mvar '
       '                                                                          '];
disp(head)
for n=1:nbus
     fprintf(' %5g', n), fprintf(' %7.3f', Vm(n)),
     fprintf(' %8.3f', deltad(n)), fprintf(' %9.2f', Pd(n)),
     fprintf(' %9.2f', Qd(n)),  fprintf(' %9.2f', Pg(n)),
     fprintf(' %9.2f ', Qg(n)), fprintf(' %8.2f\n', Qsh(n))
end
    fprintf('      \n'), fprintf('    Total              ')
    fprintf(' %9.2f', Pdt), fprintf(' %9.2f', Qdt),
    fprintf(' %9.2f', Pgt), fprintf(' %9.2f', Qgt), fprintf(' %9.2f\n\n', Qsht)
